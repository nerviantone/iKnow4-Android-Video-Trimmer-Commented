package com.iknow.android.interfaces;

/**
 * author : J.Chou
 * e-mail : who_know_me@163.com
 * time   : 2018/06/06/2:28 PM
 * version: 1.0
 * description:
 */
public interface IVideoTrimmerView {
  void onDestroy();
}
