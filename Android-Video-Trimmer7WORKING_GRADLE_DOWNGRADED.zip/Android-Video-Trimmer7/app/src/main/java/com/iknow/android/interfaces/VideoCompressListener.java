package com.iknow.android.interfaces;

import nl.bravobit.ffmpeg.ExecuteBinaryResponseHandler;

public class VideoCompressListener extends ExecuteBinaryResponseHandler {

    @Override public void onSuccess(String message) {
    }

    @Override public void onFailure(String message) {
    }
}
