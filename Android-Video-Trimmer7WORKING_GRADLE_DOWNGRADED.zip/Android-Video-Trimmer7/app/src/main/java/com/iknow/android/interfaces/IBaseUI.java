package com.iknow.android.interfaces;

/**
 * author : J.Chou
 * e-mail : who_know_me@163.com
 * time   : 2019/02/22 4:44 PM
 * version: 1.0
 * description:
 */
public interface IBaseUI {
  void initUI();
  void loadData();
}
